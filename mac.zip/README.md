# ProtectPy3
[New] Bot Saling Backup Dan Admin Di Undang Jika Ke Kick

Bot Line Versi Protect Group
- Siapkan 1 Akun Utama Dan 5 Akun Bot

Fungsinya?
Kelebihan :
1. Protect Group Line Pastinya
2. Dapat Menambah Owner,Admin/Staff Kedalam Bot
3. Command Bisa Dipakai oleh Orang Admin
4. Bot Tidak Saling Kick Ketika Ada Yang Terkick
5. Jika Ingin Protect Lebih Dari 1 Group, Kalian Tidak Wajib ada di Semua Group Tersebut

Kelemahan:
- BOT Tidak Aktif Ketika Bot Induk Tidak ada di Dalam Group
- Masih ada fitur yang belum work dan akan di post kembali

Cara Instal :
- pkg install python3
- pkg install pip3
- pkg install git
- git clone https://github.com/iiipuuul/ProtectPy3
- pip3 install rsa
- pip3 install thrift==0.9.3
- pip3 install requests

Cara Menjalankan Botnya :
- cd ProtectPy3
- python3 5bot.py
